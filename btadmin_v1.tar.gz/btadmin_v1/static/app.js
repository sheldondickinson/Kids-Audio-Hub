const knownDevicesBody = document.getElementById('known-devices-body');
const scanResultsBody = document.getElementById('scan-results-body');
const statusGrid = document.getElementById('status-grid');
const logPanel = document.getElementById('log-panel');

function log(msg, data = null) {
  const ts = new Date().toLocaleTimeString();
  const payload = data ? `\n${JSON.stringify(data, null, 2)}` : '';
  logPanel.textContent = `[${ts}] ${msg}${payload}\n\n` + logPanel.textContent;
}

function badge(value) {
  return `<span class="badge ${value ? 'ok' : 'no'}">${value ? 'Yes' : 'No'}</span>`;
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await response.json();
  if (!response.ok) throw new Error(JSON.stringify(data));
  return data;
}

function renderStatus(data) {
  const controller = data.controller || {};
  const services = data.services || {};
  const items = [
    ['Controller', controller.alias || controller.name || 'Unknown'],
    ['Powered', badge(controller.powered)],
    ['Pairable', badge(controller.pairable)],
    ['Discoverable', badge(controller.discoverable)],
    ['Bluetooth service', services.bluetooth || 'unknown'],
    ['PipeWire', services.pipewire || 'unknown'],
    ['WirePlumber', services.wireplumber || 'unknown'],
    ['KidsHub present', badge(data.kidshub_exists)],
    ['BlueZ sinks', (data.bluez_sinks || []).join(', ') || 'None'],
    ['Configured headsets', (data.configured_headsets || []).join(', ') || 'None'],
  ];
  statusGrid.innerHTML = items.map(([label, value]) => `
    <div class="status-item">
      <div class="status-label">${label}</div>
      <div class="status-value">${value}</div>
    </div>
  `).join('');
}

function actionButtons(mac, type) {
  const common = [
    `<button onclick="deviceAction('${mac}','connect')">Connect</button>`,
    `<button onclick="deviceAction('${mac}','disconnect')">Disconnect</button>`,
    `<button onclick="deviceAction('${mac}','trust')">Trust</button>`,
    `<button onclick="deviceAction('${mac}','remove')">Forget</button>`,
  ];
  if (type === 'scan') common.unshift(`<button onclick="deviceAction('${mac}','pair')">Pair</button>`);
  return `<div class="device-actions">${common.join('')}</div>`;
}

function renderKnownDevices(devices) {
  if (!devices.length) {
    knownDevicesBody.innerHTML = `<tr><td colspan="6" class="empty">No known devices.</td></tr>`;
    return;
  }
  knownDevicesBody.innerHTML = devices.map(d => `
    <tr>
      <td>${d.name || 'Unknown'}</td>
      <td><code>${d.mac}</code></td>
      <td>${badge(d.paired)}</td>
      <td>${badge(d.trusted)}</td>
      <td>${badge(d.connected)}</td>
      <td>${actionButtons(d.mac, 'known')}</td>
    </tr>
  `).join('');
}

function renderScanResults(devices) {
  if (!devices.length) {
    scanResultsBody.innerHTML = `<tr><td colspan="3" class="empty">No devices found.</td></tr>`;
    return;
  }
  scanResultsBody.innerHTML = devices.map(d => `
    <tr>
      <td>${d.name || 'Unknown'}</td>
      <td><code>${d.mac}</code></td>
      <td>${actionButtons(d.mac, 'scan')}</td>
    </tr>
  `).join('');
}

async function refreshStatus() {
  const data = await api('/api/status');
  renderStatus(data);
  renderKnownDevices(data.known_devices || []);
  log('Refreshed status');
}

async function deviceAction(mac, action) {
  log(`Running ${action} on ${mac}`);
  const data = await api(`/api/device/${mac}/${action}`, { method: 'POST' });
  log(`Finished ${action} on ${mac}`, data);
  await refreshStatus();
}
window.deviceAction = deviceAction;

async function scanDevices() {
  log('Starting Bluetooth scan');
  const data = await api('/api/scan', { method: 'POST', body: JSON.stringify({}) });
  renderScanResults(data.devices || []);
  log('Scan complete', { devices: data.devices || [] });
  await refreshStatus();
}

async function simpleAction(endpoint, label) {
  log(`Running ${label}`);
  const data = await api(endpoint, { method: 'POST', body: JSON.stringify({}) });
  log(`${label} finished`, data);
  await refreshStatus();
}

async function handleButton(action) {
  if (action === 'refresh') return refreshStatus();
  if (action === 'scan') return scanDevices();
  if (action === 'reconnect-all') return simpleAction('/api/reconnect-all', 'Reconnect all');
  if (action === 'rebuild-kidshub') return simpleAction('/api/rebuild-kidshub', 'Rebuild KidsHub');
  if (action === 'restart-services') return simpleAction('/api/restart-services', 'Restart services');
}

document.querySelectorAll('[data-action]').forEach(btn => {
  btn.addEventListener('click', async () => {
    btn.disabled = true;
    try {
      await handleButton(btn.dataset.action);
    } catch (err) {
      log(`Action failed: ${btn.dataset.action}`, { error: String(err) });
      alert('Action failed. Check the log panel.');
    } finally {
      btn.disabled = false;
    }
  });
});

refreshStatus().catch(err => {
  log('Initial load failed', { error: String(err) });
});
