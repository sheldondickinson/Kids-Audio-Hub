# btAdmin v1

First working version of a lightweight Bluetooth administration page for the Kids Audio Hub.

## What it does

- serves `/btAdmin` on port `8080`
- shows controller, PipeWire and KidsHub status
- lists known Bluetooth devices
- scans for nearby devices
- supports pair, trust, connect, disconnect and forget actions
- supports reconnect all, rebuild KidsHub and restart services actions

## What it does not do yet

- no polished pairing wizard
- no websocket live updates
- no role-based access control
- no deep PipeWire codec tuning UI

## Project structure

- `app.py` — Flask app and backend logic
- `templates/bt_admin.html` — main page
- `static/` — CSS and JS
- `.env.example` — example environment settings
- `requirements.txt` — Python packages

## Suggested repo placement

Drop these files into the repo root or under a folder such as `btadmin/`.

## Install

```bash
sudo apt update
sudo apt install -y python3-venv python3-pip bluetooth bluez pipewire pipewire-pulse wireplumber pulseaudio-utils
cd btadmin_v1
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` to set:

- `BTADMIN_USER`
- `BTADMIN_PASS`
- `HEADSET_MACS`

## Run manually

```bash
set -a
source .env
set +a
python3 app.py
```

Then browse to:

```text
http://<pi-ip>:8080/btAdmin
```

## Notes

### sudo for restart-services
The restart-services endpoint calls:

- `sudo systemctl restart bluetooth`
- `systemctl --user restart pipewire`
- `systemctl --user restart wireplumber`

For the web app user to restart Bluetooth without a password prompt, add a sudoers rule such as:

```text
<user> ALL=(ALL) NOPASSWD: /bin/systemctl restart bluetooth
```

Adjust the path if your `systemctl` binary differs.

### pactl and user session
This app assumes it is running in the same user session that owns the PipeWire and Pulse compatibility layer. If `pactl` cannot see sinks, run the app as the same desktop user that created the Bluetooth audio sinks.

## Minimal systemd unit example

```ini
[Unit]
Description=Kids Audio Hub btAdmin
After=network-online.target bluetooth.service
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/home/pi/btadmin_v1
EnvironmentFile=/home/pi/btadmin_v1/.env
ExecStart=/home/pi/btadmin_v1/.venv/bin/python /home/pi/btadmin_v1/app.py
Restart=on-failure
User=pi
Group=pi

[Install]
WantedBy=multi-user.target
```

## Recommended next steps

- add proper BlueZ D-Bus bindings instead of relying mainly on `bluetoothctl`
- add a pairing flow that automatically trusts after pair
- add a simple config page for `HEADSET_MACS`
- add CSRF protection and stronger auth if this stays long term
