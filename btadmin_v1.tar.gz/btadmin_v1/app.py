#!/usr/bin/env python3
import os
import re
import shlex
import subprocess
from functools import wraps
from typing import Dict, List, Optional

from flask import Flask, Response, jsonify, redirect, render_template, request, url_for

app = Flask(__name__)

APP_TITLE = os.getenv("BTADMIN_TITLE", "Kids Audio Hub")
KIDSHUB_SINK_NAME = os.getenv("KIDSHUB_SINK_NAME", "KidsHub")
HEADSET_MACS = [m.strip().upper() for m in os.getenv("HEADSET_MACS", "").split(",") if m.strip()]
BASIC_AUTH_USER = os.getenv("BTADMIN_USER")
BASIC_AUTH_PASS = os.getenv("BTADMIN_PASS")
SCAN_TIMEOUT_SECONDS = int(os.getenv("BTADMIN_SCAN_TIMEOUT", "12"))

DEVICE_LINE_RE = re.compile(r"^Device\s+([0-9A-F:]{17})\s+(.+)$", re.IGNORECASE)
YES_NO_RE = re.compile(r"^\s*(Paired|Trusted|Connected|Blocked):\s+(yes|no)\s*$", re.IGNORECASE | re.MULTILINE)
NAME_RE = re.compile(r"^\s*(?:Alias|Name):\s+(.+)$", re.IGNORECASE | re.MULTILINE)
ICON_RE = re.compile(r"^\s*Icon:\s+(.+)$", re.IGNORECASE | re.MULTILINE)


def require_auth(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not BASIC_AUTH_USER or not BASIC_AUTH_PASS:
            return fn(*args, **kwargs)

        auth = request.authorization
        if auth and auth.username == BASIC_AUTH_USER and auth.password == BASIC_AUTH_PASS:
            return fn(*args, **kwargs)

        return Response(
            "Authentication required",
            401,
            {"WWW-Authenticate": 'Basic realm="Kids Audio Hub Admin"'},
        )

    return wrapper


def run_command(cmd: List[str], check: bool = False, timeout: int = 30) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, check=check, timeout=timeout)


def run_shell(script: str, timeout: int = 30) -> subprocess.CompletedProcess:
    return subprocess.run(["bash", "-lc", script], capture_output=True, text=True, timeout=timeout)


def command_ok(cp: subprocess.CompletedProcess) -> bool:
    return cp.returncode == 0


def bool_from_text(value: str) -> bool:
    return value.strip().lower() == "yes"


def parse_device_info(text: str, mac: str) -> Dict:
    data = {
        "mac": mac.upper(),
        "name": mac.upper(),
        "icon": "audio-card",
        "paired": False,
        "trusted": False,
        "connected": False,
        "blocked": False,
    }
    name_match = NAME_RE.search(text)
    if name_match:
        data["name"] = name_match.group(1).strip()
    icon_match = ICON_RE.search(text)
    if icon_match:
        data["icon"] = icon_match.group(1).strip()
    for key, value in YES_NO_RE.findall(text):
        data[key.strip().lower()] = bool_from_text(value)
    return data


def bluetoothctl(*args: str, timeout: int = 30) -> subprocess.CompletedProcess:
    return run_command(["bluetoothctl", *args], timeout=timeout)


def get_controller_info() -> Dict:
    cp = bluetoothctl("show")
    if not command_ok(cp):
        return {"ok": False, "stdout": cp.stdout, "stderr": cp.stderr}

    text = cp.stdout
    powered = re.search(r"^\s*Powered:\s+(yes|no)$", text, re.MULTILINE)
    discoverable = re.search(r"^\s*Discoverable:\s+(yes|no)$", text, re.MULTILINE)
    pairable = re.search(r"^\s*Pairable:\s+(yes|no)$", text, re.MULTILINE)
    name = re.search(r"^\s*Name:\s+(.+)$", text, re.MULTILINE)
    alias = re.search(r"^\s*Alias:\s+(.+)$", text, re.MULTILINE)
    return {
        "ok": True,
        "name": name.group(1).strip() if name else None,
        "alias": alias.group(1).strip() if alias else None,
        "powered": powered.group(1).lower() == "yes" if powered else None,
        "discoverable": discoverable.group(1).lower() == "yes" if discoverable else None,
        "pairable": pairable.group(1).lower() == "yes" if pairable else None,
        "raw": text,
    }


def get_known_devices() -> List[Dict]:
    cp = bluetoothctl("devices")
    if not command_ok(cp):
        return []

    devices = []
    for line in cp.stdout.splitlines():
        m = DEVICE_LINE_RE.match(line.strip())
        if not m:
            continue
        mac = m.group(1).upper()
        info_cp = bluetoothctl("info", mac)
        if command_ok(info_cp) and info_cp.stdout.strip():
            devices.append(parse_device_info(info_cp.stdout, mac))
        else:
            devices.append({
                "mac": mac,
                "name": m.group(2).strip(),
                "paired": False,
                "trusted": False,
                "connected": False,
                "blocked": False,
                "icon": "audio-card",
            })
    devices.sort(key=lambda d: (d["name"].lower(), d["mac"]))
    return devices


def get_sink_names() -> List[str]:
    cp = run_shell("pactl list short sinks", timeout=15)
    if not command_ok(cp):
        return []
    sinks = []
    for line in cp.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 2:
            sinks.append(parts[1])
    return sinks


def get_bluez_sinks() -> List[str]:
    return [s for s in get_sink_names() if s.startswith("bluez_output.")]


def kidshub_exists() -> bool:
    return KIDSHUB_SINK_NAME in get_sink_names()


def service_state(service: str, user: bool = False) -> str:
    cmd = ["systemctl"]
    if user:
        cmd.append("--user")
    cmd.extend(["is-active", service])
    cp = run_command(cmd, timeout=15)
    return cp.stdout.strip() if cp.stdout.strip() else cp.stderr.strip() or "unknown"


def system_summary() -> Dict:
    return {
        "controller": get_controller_info(),
        "known_devices": get_known_devices(),
        "bluez_sinks": get_bluez_sinks(),
        "kidshub_exists": kidshub_exists(),
        "services": {
            "bluetooth": service_state("bluetooth"),
            "pipewire": service_state("pipewire", user=True),
            "wireplumber": service_state("wireplumber", user=True),
        },
        "configured_headsets": HEADSET_MACS,
    }


def do_bt_action(action: str, mac: str) -> Dict:
    action = action.lower()
    if action not in {"connect", "disconnect", "trust", "pair", "remove"}:
        return {"ok": False, "message": f"Unsupported action: {action}"}
    cp = bluetoothctl(action, mac)
    return {
        "ok": command_ok(cp),
        "action": action,
        "mac": mac.upper(),
        "stdout": cp.stdout,
        "stderr": cp.stderr,
    }


def scan_devices(timeout_seconds: int) -> Dict:
    script = f'''
set -e
bluetoothctl --timeout {int(timeout_seconds)} scan on || true
bluetoothctl devices
'''
    cp = run_shell(script, timeout=timeout_seconds + 10)
    found = []
    for line in cp.stdout.splitlines():
        m = DEVICE_LINE_RE.match(line.strip())
        if m:
            found.append({"mac": m.group(1).upper(), "name": m.group(2).strip()})
    deduped = {(d['mac'], d['name']): d for d in found}
    return {
        "ok": command_ok(cp),
        "devices": list(deduped.values()),
        "stdout": cp.stdout,
        "stderr": cp.stderr,
    }


def reconnect_all() -> Dict:
    devices = HEADSET_MACS or [d["mac"] for d in get_known_devices() if d.get("trusted")]
    results = []
    if not devices:
        return {"ok": False, "message": "No configured or trusted devices available to reconnect."}
    for mac in devices:
        cp = bluetoothctl("connect", mac)
        results.append({
            "mac": mac,
            "ok": command_ok(cp),
            "stdout": cp.stdout,
            "stderr": cp.stderr,
        })
    return {"ok": any(r["ok"] for r in results), "results": results}


def rebuild_kidshub() -> Dict:
    sinks = get_bluez_sinks()
    if not sinks:
        return {"ok": False, "message": "No Bluetooth audio sinks found."}

    unload = run_shell(
        f"pactl unload-module module-combine-sink >/dev/null 2>&1 || true; "
        f"for m in $(pactl list short modules | awk '/module-combine-sink/ {{print $1}}'); do pactl unload-module $m || true; done",
        timeout=20,
    )
    load = run_shell(
        f"pactl load-module module-combine-sink sink_name={shlex.quote(KIDSHUB_SINK_NAME)} slaves={','.join(shlex.quote(s) for s in sinks)}",
        timeout=20,
    )
    default_cp = run_shell(f"pactl set-default-sink {shlex.quote(KIDSHUB_SINK_NAME)}", timeout=15)
    return {
        "ok": command_ok(load) and command_ok(default_cp),
        "sinks": sinks,
        "unload_stdout": unload.stdout,
        "unload_stderr": unload.stderr,
        "load_stdout": load.stdout,
        "load_stderr": load.stderr,
        "default_stdout": default_cp.stdout,
        "default_stderr": default_cp.stderr,
    }


def restart_services() -> Dict:
    steps = []
    for cmd in (
        ["sudo", "systemctl", "restart", "bluetooth"],
        ["systemctl", "--user", "restart", "pipewire"],
        ["systemctl", "--user", "restart", "wireplumber"],
    ):
        cp = run_command(cmd, timeout=30)
        steps.append({"cmd": " ".join(cmd), "ok": command_ok(cp), "stdout": cp.stdout, "stderr": cp.stderr})
    return {"ok": all(s["ok"] for s in steps), "steps": steps}


@app.route("/")
@require_auth
def root():
    return redirect(url_for("bt_admin"))


@app.route("/btAdmin")
@require_auth
def bt_admin():
    return render_template("bt_admin.html", title=APP_TITLE)


@app.route("/api/status")
@require_auth
def api_status():
    return jsonify(system_summary())


@app.route("/api/scan", methods=["POST"])
@require_auth
def api_scan():
    timeout = request.json.get("timeout", SCAN_TIMEOUT_SECONDS) if request.is_json else SCAN_TIMEOUT_SECONDS
    return jsonify(scan_devices(int(timeout)))


@app.route("/api/device/<mac>/<action>", methods=["POST"])
@require_auth
def api_device_action(mac: str, action: str):
    return jsonify(do_bt_action(action, mac))


@app.route("/api/reconnect-all", methods=["POST"])
@require_auth
def api_reconnect_all():
    return jsonify(reconnect_all())


@app.route("/api/rebuild-kidshub", methods=["POST"])
@require_auth
def api_rebuild_kidshub():
    return jsonify(rebuild_kidshub())


@app.route("/api/restart-services", methods=["POST"])
@require_auth
def api_restart_services():
    return jsonify(restart_services())


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8080")), debug=False)
